package com.fliptime.platecases;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ChestManager {

    public record Data(String id, String world, int x, int y, int z, String type) {}

    /** Тимчасове вікно з лутом. Закрив — вміст зникає. */
    public static class LootHolder implements InventoryHolder {
        public final String blockKey;
        public Inventory inv;

        public LootHolder(String blockKey) {
            this.blockKey = blockKey;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final PlateCasesPlugin plugin;
    private final File file;
    private final Map<String, Data> byKey = new LinkedHashMap<>();
    private final Map<String, UUID> sessions = new HashMap<>();

    public ChestManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "chests.yml");
    }

    public static String key(Block b) {
        return b.getWorld().getName() + ";" + b.getX() + ";" + b.getY() + ";" + b.getZ();
    }

    private static String key(Data d) {
        return d.world() + ";" + d.x() + ";" + d.y() + ";" + d.z();
    }

    public void load() {
        byKey.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("chests");
        if (s == null) return;
        for (String id : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(id);
            if (c == null) continue;
            Data d = new Data(id, c.getString("world", "world"), c.getInt("x"), c.getInt("y"), c.getInt("z"),
                    c.getString("type", "chest"));
            byKey.put(key(d), d);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Data d : byKey.values()) {
            String p = "chests." + d.id();
            y.set(p + ".world", d.world());
            y.set(p + ".x", d.x());
            y.set(p + ".y", d.y());
            y.set(p + ".z", d.z());
            y.set(p + ".type", d.type());
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Не вдалося зберегти chests.yml: " + e.getMessage());
        }
    }

    public boolean isSpecial(Block b) {
        return b != null && byKey.containsKey(key(b));
    }

    public Data get(Block b) {
        return b == null ? null : byKey.get(key(b));
    }

    public List<Data> all() {
        return new ArrayList<>(byKey.values());
    }

    public Data create(Block b, String type) {
        int n = 1;
        for (Data d : byKey.values()) {
            if (d.id().startsWith("c")) {
                try {
                    n = Math.max(n, Integer.parseInt(d.id().substring(1)) + 1);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        Data d = new Data("c" + n, b.getWorld().getName(), b.getX(), b.getY(), b.getZ(), type);
        byKey.put(key(d), d);
        save();
        return d;
    }

    /** Видаляє запис і сам блок. */
    public boolean remove(Data d) {
        if (d == null) return false;
        String k = key(d);
        byKey.remove(k);
        closeViewers(k);
        World w = Bukkit.getWorld(d.world());
        if (w != null) w.getBlockAt(d.x(), d.y(), d.z()).setType(Material.AIR);
        save();
        return true;
    }

    public Data byId(String id) {
        for (Data d : byKey.values()) if (d.id().equalsIgnoreCase(id)) return d;
        return null;
    }

    public boolean isBusy(String blockKey) {
        return sessions.containsKey(blockKey);
    }

    public void endSession(String blockKey) {
        sessions.remove(blockKey);
    }

    private void closeViewers(String blockKey) {
        UUID u = sessions.get(blockKey);
        if (u == null) return;
        Player p = Bukkit.getPlayer(u);
        if (p != null) p.closeInventory();
        sessions.remove(blockKey);
    }

    public void closeAll() {
        for (String k : new ArrayList<>(sessions.keySet())) closeViewers(k);
    }

    public void open(Player p, Block block, Data d, String plateId, List<ItemStack> items) {
        ConfigurationSection ps = plugin.plates().section(plateId);
        int def = 27;
        int size = plugin.getConfig().getInt(d.type().equals("barrel") ? "chests.barrel-size" : "chests.chest-size", def);
        size = Math.max(9, Math.min(54, (size / 9) * 9));

        LootHolder h = new LootHolder(key(block));
        String title = ps == null ? "&6Скарбниця" : ps.getString("chest-name", "&6Скарбниця");
        Inventory inv = Bukkit.createInventory(h, size, PlateCasesPlugin.color(title));
        h.inv = inv;
        for (ItemStack it : items) inv.addItem(it);

        sessions.put(h.blockKey, p.getUniqueId());
        p.openInventory(inv);

        if (ps == null) return;
        Location loc = block.getLocation().add(0.5, 0.8, 0.5);
        if (plugin.getConfig().getBoolean("effects.sounds-enabled", true)) {
            try {
                block.getWorld().playSound(loc, ps.getString("open-sound", "entity.player.levelup"),
                        (float) ps.getDouble("sound-volume", 1.0), (float) ps.getDouble("sound-pitch", 1.0));
            } catch (Throwable ignored) {
            }
        }
        if (plugin.getConfig().getBoolean("effects.particles-enabled", true) && ps.getBoolean("particles", true)) {
            try {
                Particle part = Particle.valueOf(ps.getString("particle", "happy_villager").toUpperCase());
                block.getWorld().spawnParticle(part, loc, ps.getInt("particle-count", 30), 0.4, 0.4, 0.4, 0.05);
            } catch (Throwable ignored) {
            }
        }
    }
}
