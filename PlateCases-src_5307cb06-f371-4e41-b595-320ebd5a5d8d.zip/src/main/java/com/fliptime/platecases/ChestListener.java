package com.fliptime.platecases;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ChestListener implements Listener {

    private static final BlockFace[] SIDES = {BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};

    private final PlateCasesPlugin plugin;
    private final Map<UUID, Long> cooldown = new HashMap<>();

    public ChestListener(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        Player p = e.getPlayer();
        Action a = e.getAction();

        // платівку не можна вставити в програвач
        if (a == Action.RIGHT_CLICK_BLOCK && b.getType() == Material.JUKEBOX
                && plugin.plates().readId(p.getInventory().getItemInMainHand()) != null) {
            e.setCancelled(true);
            return;
        }

        ChestManager.Data d = plugin.chests().get(b);
        if (d == null) return;

        e.setCancelled(true); // ванільне відкриття завжди заборонене
        if (a != Action.RIGHT_CLICK_BLOCK) return;

        if (!p.hasPermission("platecases.use")) {
            p.sendMessage(plugin.msg("no-permission"));
            return;
        }

        long now = System.currentTimeMillis();
        long cd = plugin.getConfig().getLong("settings.open-cooldown-ms", 400);
        Long last = cooldown.get(p.getUniqueId());
        if (last != null && now - last < cd) return;
        cooldown.put(p.getUniqueId(), now);

        ItemStack hand = p.getInventory().getItemInMainHand();
        String plateId = plugin.plates().readId(hand);
        if (plateId == null) {
            if (plugin.plates().readId(p.getInventory().getItemInOffHand()) != null) {
                p.sendMessage(plugin.msg("plate-offhand"));
            } else {
                p.sendMessage(plugin.msg("hold-plate"));
            }
            return;
        }
        if (plugin.plates().section(plateId) == null) {
            p.sendMessage(plugin.msg("fake-plate"));
            return;
        }
        if (plugin.chests().isBusy(ChestManager.key(b))) {
            p.sendMessage(plugin.msg("busy"));
            return;
        }

        List<ItemStack> items = plugin.loot().roll(plugin.plates().level(plateId));
        if (items.isEmpty()) {
            p.sendMessage(plugin.msg("loot-empty"));
            return;
        }

        // витрачаємо рівно одну платівку
        if (hand.getAmount() <= 1) {
            p.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }

        String plateName = plugin.plates().section(plateId).getString("name", plateId);
        plugin.chests().open(p, b, d, plateId, items);
        p.sendMessage(plugin.msg("opened", "plate", plateName));
    }

    // ---------- вікно з лутом ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof ChestManager.LootHolder)) return;
        Inventory clicked = e.getClickedInventory();
        if (clicked == null) return;
        InventoryAction act = e.getAction();
        if (clicked.equals(top)) {
            boolean allowed = act == InventoryAction.PICKUP_ALL || act == InventoryAction.PICKUP_HALF
                    || act == InventoryAction.PICKUP_ONE || act == InventoryAction.PICKUP_SOME
                    || act == InventoryAction.MOVE_TO_OTHER_INVENTORY
                    || act == InventoryAction.DROP_ALL_SLOT || act == InventoryAction.DROP_ONE_SLOT
                    || act == InventoryAction.NOTHING;
            if (!allowed) e.setCancelled(true);
        } else if (act == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            e.setCancelled(true); // не дати покласти свої предмети у вікно
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof ChestManager.LootHolder)) return;
        for (int slot : e.getRawSlots()) {
            if (slot < top.getSize()) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (!(inv.getHolder() instanceof ChestManager.LootHolder h)) return;
        boolean left = false;
        for (ItemStack it : inv.getContents()) {
            if (it != null && !it.getType().isAir()) {
                left = true;
                break;
            }
        }
        inv.clear(); // залишок луту зникає назавжди
        plugin.chests().endSession(h.blockKey);
        if (left && e.getPlayer() instanceof Player p) {
            p.sendMessage(plugin.msg("closed-lost"));
        }
    }

    // ---------- захист блоків ----------

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (plugin.chests().isSpecial(e.getBlock())) {
            e.setCancelled(true);
            e.getPlayer().sendMessage(plugin.msg("break-denied"));
        }
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.chests().isSpecial(b));
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        e.blockList().removeIf(b -> plugin.chests().isSpecial(b));
    }

    @EventHandler
    public void onPistonExtend(BlockPistonExtendEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.chests().isSpecial(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onPistonRetract(BlockPistonRetractEvent e) {
        for (Block b : e.getBlocks()) {
            if (plugin.chests().isSpecial(b)) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        Material t = e.getBlockPlaced().getType();
        if (t != Material.CHEST && t != Material.TRAPPED_CHEST) return;
        for (BlockFace f : SIDES) {
            if (plugin.chests().isSpecial(e.getBlockPlaced().getRelative(f))) {
                e.setCancelled(true);
                e.getPlayer().sendMessage(plugin.msg("adjacent-denied"));
                return;
            }
        }
    }
}
