package com.fliptime.platecases;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class LootManager {

    private record Entry(ItemStack item, double chance, int min, int max) {}

    private record Table(int rolls, List<Entry> entries) {}

    private final PlateCasesPlugin plugin;
    private final Map<Integer, Table> cache = new HashMap<>();

    public LootManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
    }

    public void clear() {
        cache.clear();
    }

    private Table table(int level) {
        return cache.computeIfAbsent(level, this::load);
    }

    private Table load(int level) {
        File f = new File(plugin.getDataFolder(), "loot/level" + level + ".yml");
        if (!f.exists()) return new Table(1, new ArrayList<>());
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        List<Entry> list = new ArrayList<>();
        ConfigurationSection es = y.getConfigurationSection("entries");
        if (es != null) {
            for (String k : es.getKeys(false)) {
                ConfigurationSection e = es.getConfigurationSection(k);
                if (e == null) continue;
                ItemStack item = null;
                if (e.isItemStack("item")) {
                    item = e.getItemStack("item");
                } else {
                    Material m = Material.matchMaterial(e.getString("material", ""));
                    if (m == null || m.isAir()) {
                        plugin.getLogger().warning("loot/level" + level + ".yml: невідомий матеріал у '" + k + "'");
                        continue;
                    }
                    item = new ItemStack(m);
                    String potion = e.getString("potion");
                    if (potion != null && item.getItemMeta() instanceof PotionMeta pm) {
                        try {
                            pm.setBasePotionType(PotionType.valueOf(potion.toUpperCase()));
                            item.setItemMeta(pm);
                        } catch (IllegalArgumentException ex) {
                            plugin.getLogger().warning("loot/level" + level + ".yml: невідоме зілля '" + potion + "'");
                        }
                    }
                }
                if (item == null) continue;
                int min = e.getInt("min", 1);
                int max = e.getInt("max", min);
                if (max < min) { int t = min; min = max; max = t; }
                list.add(new Entry(item, e.getDouble("chance", 100.0), Math.max(1, min), Math.max(1, max)));
            }
        }
        return new Table(Math.max(1, y.getInt("rolls", 1)), list);
    }

    /** Генерує лут для рівня. Порожній список = лут не налаштовано. */
    public List<ItemStack> roll(int level) {
        Table t = table(level);
        List<ItemStack> out = new ArrayList<>();
        if (t.entries().isEmpty()) return out;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        for (int i = 0; i < t.rolls(); i++) {
            for (Entry e : t.entries()) {
                if (r.nextDouble() * 100.0 >= e.chance()) continue;
                int amount = e.min() == e.max() ? e.min() : r.nextInt(e.min(), e.max() + 1);
                int ms = Math.max(1, e.item().getMaxStackSize());
                while (amount > 0) {
                    ItemStack c = e.item().clone();
                    int n = Math.min(ms, amount);
                    c.setAmount(n);
                    out.add(c);
                    amount -= n;
                }
            }
        }
        return out;
    }
}
