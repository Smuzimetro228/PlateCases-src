package com.fliptime.platecases;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class PlateManager {

    private final PlateCasesPlugin plugin;
    private final NamespacedKey key;

    public PlateManager(PlateCasesPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "plate_id");
    }

    public Set<String> ids() {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("plates");
        if (s == null) return Collections.emptySet();
        return new LinkedHashSet<>(s.getKeys(false));
    }

    public ConfigurationSection section(String id) {
        if (id == null) return null;
        return plugin.getConfig().getConfigurationSection("plates." + id);
    }

    public int level(String id) {
        ConfigurationSection s = section(id);
        return s == null ? 0 : s.getInt("level", 1);
    }

    /** Створює ОДНУ платівку (музичні диски не стакаються). */
    public ItemStack create(String id) {
        ConfigurationSection s = section(id);
        if (s == null) return null;
        Material m = Material.matchMaterial(s.getString("material", "MUSIC_DISC_CREATOR"));
        if (m == null || m.isAir()) m = Material.MUSIC_DISC_CREATOR;
        ItemStack it = new ItemStack(m, 1);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(PlateCasesPlugin.color(s.getString("name", id)));
        List<Component> lore = new ArrayList<>();
        for (String l : s.getStringList("lore")) lore.add(PlateCasesPlugin.color(l));
        meta.lore(lore);
        int cmd = s.getInt("custom-model-data", 0);
        if (cmd > 0) meta.setCustomModelData(cmd);
        if (s.getBoolean("glow", false)) meta.setEnchantmentGlintOverride(true);
        meta.addItemFlags(ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, id);
        it.setItemMeta(meta);
        return it;
    }

    /** Повертає id платівки або null, якщо предмет — не платівка. */
    public String readId(ItemStack it) {
        if (it == null || it.getType().isAir() || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }
}
