package com.fliptime.platecases;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PlateCasesPlugin extends JavaPlugin implements TabExecutor {

    private static final LegacyComponentSerializer LEGACY =
            LegacyComponentSerializer.builder().character('&').hexColors().build();

    private PlateManager plates;
    private LootManager loot;
    private ChestManager chests;
    private FileConfiguration messages;

    public static Component color(String s) {
        return LEGACY.deserialize(s == null ? "" : s).decoration(TextDecoration.ITALIC, false);
    }

    public PlateManager plates() { return plates; }
    public LootManager loot() { return loot; }
    public ChestManager chests() { return chests; }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String f : new String[]{"messages.yml", "loot/level1.yml", "loot/level2.yml", "loot/level3.yml"}) {
            if (!new File(getDataFolder(), f).exists()) saveResource(f, false);
        }
        plates = new PlateManager(this);
        loot = new LootManager(this);
        chests = new ChestManager(this);
        loadMessages();
        chests.load();

        Bukkit.getPluginManager().registerEvents(new ChestListener(this), this);
        getCommand("pcases").setExecutor(this);
        getCommand("pcases").setTabCompleter(this);
        getLogger().info("PlateCases 2.0 увімкнено. Сундуків: " + chests.all().size());
    }

    @Override
    public void onDisable() {
        if (chests != null) {
            chests.closeAll();
            chests.save();
        }
    }

    private void loadMessages() {
        messages = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
    }

    private void reloadAll() {
        reloadConfig();
        loadMessages();
        loot.clear();
    }

    public Component msg(String key, String... kv) {
        return color(raw(key, kv));
    }

    private String raw(String key, String... kv) {
        String s = messages.getString(key, key);
        s = s.replace("{prefix}", messages.getString("prefix", ""));
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        return s;
    }

    // ---------- команди ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("platecases.admin")) {
            sender.sendMessage(msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "place" -> place(sender, args);
            case "give" -> give(sender, args);
            case "remove" -> remove(sender, args);
            case "list" -> list(sender);
            case "reload" -> {
                reloadAll();
                sender.sendMessage(msg("reloaded"));
            }
            default -> help(sender);
        }
        return true;
    }

    private void help(CommandSender s) {
        for (String l : messages.getStringList("help")) s.sendMessage(color(l));
    }

    private void place(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(msg("players-only"));
            return;
        }
        if (args.length < 2 || !(args[1].equalsIgnoreCase("chest") || args[1].equalsIgnoreCase("barrel"))) {
            p.sendMessage(msg("usage-place"));
            return;
        }
        boolean barrel = args[1].equalsIgnoreCase("barrel");
        BlockFace facing = p.getFacing();
        Block b = p.getLocation().getBlock().getRelative(facing);
        if (!b.getType().isAir()) {
            p.sendMessage(msg("place-blocked"));
            return;
        }
        if (!barrel) {
            for (BlockFace f : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
                Material t = b.getRelative(f).getType();
                if (t == Material.CHEST || t == Material.TRAPPED_CHEST) {
                    p.sendMessage(msg("place-adjacent"));
                    return;
                }
            }
        }
        b.setType(barrel ? Material.BARREL : Material.CHEST);
        BlockData bd = b.getBlockData();
        if (bd instanceof Directional dir) {
            dir.setFacing(facing.getOppositeFace());
            b.setBlockData(dir);
        }
        ChestManager.Data d = chests.create(b, barrel ? "barrel" : "chest");
        p.sendMessage(msg("place-success", "type", d.type(), "id", d.id()));
    }

    private void give(CommandSender sender, String[] args) {
        Player target;
        String plateId;
        int amount = 1;
        int idx;
        if (args.length >= 3 && Bukkit.getPlayerExact(args[1]) != null && plates.section(args[1]) == null) {
            target = Bukkit.getPlayerExact(args[1]);
            plateId = args[2];
            idx = 3;
        } else if (args.length >= 2) {
            if (!(sender instanceof Player self)) {
                sender.sendMessage(msg("usage-give"));
                return;
            }
            target = self;
            plateId = args[1];
            idx = 2;
        } else {
            sender.sendMessage(msg("usage-give"));
            return;
        }
        if (plates.section(plateId) == null) {
            sender.sendMessage(msg("plate-not-found"));
            return;
        }
        if (args.length > idx) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[idx])));
            } catch (NumberFormatException ex) {
                sender.sendMessage(msg("usage-give"));
                return;
            }
        }
        for (int i = 0; i < amount; i++) {
            ItemStack it = plates.create(plateId);
            for (ItemStack left : target.getInventory().addItem(it).values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), left);
            }
        }
        String name = plates.section(plateId).getString("name", plateId);
        sender.sendMessage(msg("plate-given", "amount", String.valueOf(amount), "plate", name, "player", target.getName()));
        if (target != sender) {
            target.sendMessage(msg("plate-received", "amount", String.valueOf(amount), "plate", name));
        }
    }

    private void remove(CommandSender sender, String[] args) {
        ChestManager.Data d = null;
        if (args.length >= 2) {
            d = chests.byId(args[1]);
        } else if (sender instanceof Player p) {
            Block t = p.getTargetBlockExact(6);
            d = chests.get(t);
        }
        if (d == null) {
            sender.sendMessage(msg("remove-not-found"));
            return;
        }
        String id = d.id();
        chests.remove(d);
        sender.sendMessage(msg("remove-success", "id", id));
    }

    private void list(CommandSender sender) {
        List<ChestManager.Data> all = chests.all();
        if (all.isEmpty()) {
            sender.sendMessage(msg("list-empty"));
            return;
        }
        sender.sendMessage(msg("list-header", "total", String.valueOf(all.size())));
        for (ChestManager.Data d : all) {
            sender.sendMessage(msg("list-line", "id", d.id(), "world", d.world(),
                    "x", String.valueOf(d.x()), "y", String.valueOf(d.y()), "z", String.valueOf(d.z()),
                    "type", d.type()));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("platecases.admin")) return out;
        if (args.length == 1) {
            for (String s : List.of("place", "give", "remove", "list", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2) {
            String a = args[0].toLowerCase(Locale.ROOT);
            String pre = args[1].toLowerCase(Locale.ROOT);
            if (a.equals("place")) {
                for (String s : List.of("chest", "barrel")) if (s.startsWith(pre)) out.add(s);
            } else if (a.equals("give")) {
                for (String s : plates.ids()) if (s.toLowerCase(Locale.ROOT).startsWith(pre)) out.add(s);
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getName().toLowerCase(Locale.ROOT).startsWith(pre)) out.add(p.getName());
                }
            } else if (a.equals("remove")) {
                for (ChestManager.Data d : chests.all()) if (d.id().startsWith(pre)) out.add(d.id());
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (String s : plates.ids()) if (s.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
